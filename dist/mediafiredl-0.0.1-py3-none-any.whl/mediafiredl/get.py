print("Mediafire-DL Module first commit.")

class Download():
    def __init__(self):
        print("Download class.")